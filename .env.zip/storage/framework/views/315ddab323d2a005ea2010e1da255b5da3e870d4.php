

<?php $__env->startSection('content'); ?>

    <div class="container text-white py-4">
        <h3>Privacy Policy</h3>
        <div>
            <p>We will update it very soon.</p>
        </div>    
    </div>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\laravel projects\themoviecineplex\resources\views/privacy-policy.blade.php ENDPATH**/ ?>