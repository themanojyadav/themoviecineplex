<div class="col-md-3 col-sm-6 col-12 movies-col">
                        
    <div class="ps-movie-col">
        <a href="<?php echo e(route('movies.show', $movie['id'])); ?>">
            <div class="card">
                    <img src="<?php echo e($movie['poster_path']); ?>" class="card-img-top" alt="<?php echo e($movie['title']); ?>">
                
                <div class="card-body p-3">
                    <h5 class="card-title"><?php echo e($movie['title']); ?></h5>
                    <div class="ps-col-rating-col">
                        <span class="fa fa-star text-orange"></span><?php echo e($movie['vote_average']); ?> | <span><?php echo e($movie['release_date']); ?></span>
                    </div>
                    <div class="ps-col-info-col">
                        <?php echo e($movie['genres']); ?>

                    </div>
                </div>
            </div>
        </a>
    </div>

</div><?php /**PATH D:\Projects\laravel projects\themoviecineplex\resources\views/components/movie-card.blade.php ENDPATH**/ ?>