<div class="col-md-3 col-sm-6 col-12 tv-shows-col">
                        
    <div class="ps-movie-col">
        <a href="<?php echo e(route('tv-shows.show', $show['id'])); ?>">
            <div class="card">
                    <img src="<?php echo e($show['poster_path']); ?>" class="card-img-top" alt="<?php echo e($show['name']); ?>">
                
                <div class="card-body p-3">
                    <h5 class="card-title"><?php echo e($show['name']); ?></h5>
                    <div class="ps-col-rating-col">
                        <span class="fa fa-star text-orange"></span><?php echo e($show['vote_average']); ?> | <span><?php echo e($show['first_air_date']); ?></span>
                    </div>
                    <div class="ps-col-info-col">
                        <?php echo e($show['genres']); ?>

                    </div>
                </div>
            </div>
        </a>
    </div>

</div><?php /**PATH D:\Projects\laravel projects\themoviecineplex\resources\views/components/show-card.blade.php ENDPATH**/ ?>