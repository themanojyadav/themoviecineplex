

<?php $__env->startSection('content'); ?>

    
    <section class="popular-sec py-md-5 py-sm-4 py-3 light-border-bottom">
        <div class="container">

            <div class="row">
                <div class="col">
                    <h5 class="text-uppercase text-white font-weight-bold mb-2"><i class="fas fa-fire-alt"></i> Popular Movies</h5>
                </div>
            </div>

            <div class="row">

                <?php $__currentLoopData = $popularMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if (isset($component)) { $__componentOriginalf6cc4121defb57aafadc06ceee38d5bd5a1b9d5c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MovieCard::class, ['movie' => $movie]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf6cc4121defb57aafadc06ceee38d5bd5a1b9d5c)): ?>
<?php $component = $__componentOriginalf6cc4121defb57aafadc06ceee38d5bd5a1b9d5c; ?>
<?php unset($__componentOriginalf6cc4121defb57aafadc06ceee38d5bd5a1b9d5c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="row text-center mt-3">
                <div class="col">
                    <a href="<?php echo e(route('movies.index')); ?>" class="btn btn-warning"><span class="far fa-paper-plane"></span> View All Movies</a>
                </div>
            </div>

        </div>
    </section>

    
    <section class="popular-sec py-md-5 py-sm-4 py-3">
        <div class="container">

            <div class="row">
                <div class="col">
                    <h5 class="text-uppercase text-white font-weight-bold mb-2"><i class="fas fa-fire-alt"></i> Popular Shows</h5>
                </div>
            </div>

            <div class="row">

                <?php $__currentLoopData = $popularShows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if (isset($component)) { $__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ShowCard::class, ['show' => $show]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d)): ?>
<?php $component = $__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d; ?>
<?php unset($__componentOriginal76be42813c7ff4c85aca68ffe93eaa12d27c312d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="row text-center mt-3">
                <div class="col">
                    <a href="<?php echo e(route('tv-shows.index')); ?>" class="btn btn-warning"><span class="far fa-paper-plane"></span> View All Shows</a>
                </div>
            </div>

        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\laravel projects\themoviecineplex\resources\views/homepage.blade.php ENDPATH**/ ?>