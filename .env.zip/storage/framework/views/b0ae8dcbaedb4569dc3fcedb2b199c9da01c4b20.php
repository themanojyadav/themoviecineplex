

<?php $__env->startSection('content'); ?>
    
    <?php if(count($movies) > 0): ?>
        
        <section class="now-playing-sec py-5">
            <div class="container">

                <div class="row">
                    <div class="col">
                        <h5 class="text-uppercase text-white font-weight-bold mb-2"><i class="fas fa-fire-alt"></i> <?php echo e($heading_title); ?></h5>
                    </div>
                </div>

                <div class="row movies-rows">

                    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php if (isset($component)) { $__componentOriginalf6cc4121defb57aafadc06ceee38d5bd5a1b9d5c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MovieCard::class, ['movie' => $movie]); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf6cc4121defb57aafadc06ceee38d5bd5a1b9d5c)): ?>
<?php $component = $__componentOriginalf6cc4121defb57aafadc06ceee38d5bd5a1b9d5c; ?>
<?php unset($__componentOriginalf6cc4121defb57aafadc06ceee38d5bd5a1b9d5c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="row text-center mt-4">
                    <div class="col">
                        <button class="btn btn-warning view-more-button"><span class="fas fa-sync"></span> Load More</button>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col text-center">
                        <div class="page-load-status" style="display: none;">
                            <div class="infinite-scroll-request spinner-border text-light mx-auto" role="status">
                                <span class="sr-only">Loading...</span>
                            </div>
    
                            <p class="infinite-scroll-last text-orange text-lg">End of content</p>
                            <p class="infinite-scroll-error text-orange text-lg">No more pages to load</p>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages-custom-script'); ?>
    <script>
        var path = "<?php echo e($paging_path); ?>";

        var elem = document.querySelector('.movies-rows');
        var infScroll = new InfiniteScroll( elem, {
            // options
            path: path,
            append: '.movies-col',
            history: false,
            button: '.view-more-button',
            // using button, disable loading on scroll 
            scrollThreshold: false,
            status: '.page-load-status'
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\laravel projects\themoviecineplex\resources\views/movies/movies.blade.php ENDPATH**/ ?>