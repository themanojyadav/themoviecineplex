

<?php $__env->startSection('content'); ?>
    <section class="show-movie-sec py-5 text-white">
        <div class="container">

            <div class="row">

                <div class="col-md-4 col-sm-12 col-12">
                    <div class="sm-img-col">
                        <?php if($movie['poster_path']): ?>
                            <img src="<?php echo e($movie['poster_path']); ?>" alt="<?php echo e($movie['title']); ?>" class="w-100 show-poster-img">
                        <?php else: ?>
                            <img src="<?php echo e(asset('img/movie-poster-no-image.jpg')); ?>" alt="<?php echo e($movie['title']); ?>" class="w-100 show-poster-img">
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-8 col-sm-12 col-12">
                    <div class="sm-det-col px-3 py-md-2 pt-4">
                        <h2 class="font-weight-bolder"><?php echo e($movie['title']); ?></h2>
                        <div class="sm-rdg-col">
                            <span class="fa fa-star text-orange"></span><?php echo e($movie['vote_average']); ?> | <span class="sm-rdg-date"><?php echo e($movie['release_date']); ?></span> | 
                            <span class="sm-rdg-genre">
                                <?php echo e($movie['genres']); ?>

                            </span>
                        </div>

                        <div class="sm-desc-col my-4">
                            <p>
                                <?php echo e($movie['overview']); ?>

                            </p>
                        </div>

                        <div class="tmdb-col mb-4">
                            <a href="https://www.themoviedb.org" target="_BLANK"><img src="<?php echo e(asset('img/tmdb_logo.svg')); ?>" alt="The movie database" class="show-tmdb-logo-img"></a>
                        </div>

                        <div class="sm-feat-crew-col">
                            <h6 class="font-weight-bold text-orange">Featured Crew</h6>
                            <div class="row">

                                <?php $__currentLoopData = $movie['crew']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-3 col-sm-6 col-12 mt-md-0 mt-2">
                                            <h6 class="mb-0"><?php echo e($crew['name']); ?></h6>
                                            <small><?php echo e($crew['department']); ?></small>
                                        </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>

                        <?php if($movie['videos']['results']): ?>
                            <div class="sm-btn-col mt-4">
                                <button class="btn btn-warning" data-toggle="modal" data-target="#videoModal"><i class="fa fa-play-circle"></i> Watch Trailer</a>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade" id="videoModal" tabindex="-1" role="dialog" aria-labelledby="videoModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="embed-responsive embed-responsive-16by9">
                                                <iframe id="videoPlayer" class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo e($movie['videos']['results'][0]['key']); ?>" allowfullscreen></iframe>
                                              </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        <?php endif; ?>
                    </div>
                </div>

            </div>

        </div>
    </section>    

    
    <section class="show-cast-sec py-4 light-border-bottom">
        <div class="container">

            <div class="row">
                <div class="col">
                    <h4 class="text-white font-weight-bold mb-3"><i class="fa fa-users"></i> Cast</h4>
                </div>
            </div>

            <div class="row">

                <?php $__currentLoopData = $movie['cast']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 col-sm-6 col-12 mb-3">
                        <a href="<?php echo e(route('actors.show', $cast['id'])); ?>">
                            <div class="card">
                                <?php if($cast['profile_path']): ?>
                                    <img src="<?php echo e('https://image.tmdb.org/t/p/w300/'.$cast['profile_path']); ?>" alt="Cast Image" class="w-100 card-img-top">

                                <?php else: ?>
                                    <img src="<?php echo e(asset('img/cast-no-image.jpg')); ?>" alt="No IMage" class="w-100 card-img-top">
                                <?php endif; ?>
                                <div class="card-body">
                                    <h5><?php echo e($cast['name']); ?></h5>
                                    <h6><?php echo e($cast['character']); ?></h6>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </section>

    
    <?php if(count($movie['images']) > 0): ?>
        <section class="show-cast-sec py-4">
            <div class="container">

                <div class="row">
                    <div class="col">
                        <h4 class="text-white font-weight-bold mb-3"><i class="far fa-images"></i> Images</h4>
                    </div>
                </div>

                <div class="row">

                    <?php $__currentLoopData = $movie['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-sm-6 col-12 mb-3">
                            <div class="card">
                                <a data-fancybox="gallery" href="<?php echo e('https://image.tmdb.org/t/p/original/'.$image['file_path']); ?>">
                                <img src="<?php echo e('https://image.tmdb.org/t/p/w500/'.$image['file_path']); ?>" alt="Cast Image" class="w-100 card-img-top">
                            </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>
            </div>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\laravel projects\themoviecineplex\resources\views/movies/show.blade.php ENDPATH**/ ?>