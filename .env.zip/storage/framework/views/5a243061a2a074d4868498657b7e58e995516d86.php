

<?php $__env->startSection('content'); ?>
    
    
    <section class="actors-sec py-md-4 py-sm-4 py-3 light-border-bottom">
        <div class="container">

            <div class="row">
                <div class="col">
                    <h5 class="text-uppercase text-white font-weight-bold mb-2"><i class="fas fa-fire-alt"></i> Actors</h5>
                </div>
            </div>

            <div class="row actors-rows">

                <?php $__currentLoopData = $popularActors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 actors-col">
                        
                        <div class="ps-movie-col">
                            <a href="<?php echo e(route('actors.show', $actor['id'])); ?>">
                                <div class="card">
                                        <img src="<?php echo e($actor['profile_path']); ?>" class="card-img-top" alt="<?php echo e($actor['name']); ?>">
                                    
                                    <div class="card-body p-3">
                                        <h5 class="card-title"><?php echo e($actor['name']); ?></h5>
                                        <div class="ps-col-info-col text-truncate">
                                            <?php echo e($actor['known_for']); ?>

                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="row text-center mt-4">
                <div class="col">
                    <button class="btn btn-warning view-more-button"><span class="fas fa-sync"></span> Load More</button>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col text-center">
                    <div class="page-load-status" style="display: none;">
                        <div class="infinite-scroll-request spinner-border text-light mx-auto" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>

                        <p class="infinite-scroll-last text-orange text-lg">End of content</p>
                        <p class="infinite-scroll-error text-orange text-lg">No more pages to load</p>
                    </div>
                </div>
            </div>

        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('pages-custom-script'); ?>
    <script>
        var elem = document.querySelector('.actors-rows');
        var infScroll = new InfiniteScroll( elem, {
            // options
            path: '/actors/page/{{#}}',
            append: '.actors-col',
            history: false,
            button: '.view-more-button',
            // using button, disable loading on scroll 
            scrollThreshold: false,
            status: '.page-load-status'
        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\laravel projects\themoviecineplex\resources\views/actors/index.blade.php ENDPATH**/ ?>