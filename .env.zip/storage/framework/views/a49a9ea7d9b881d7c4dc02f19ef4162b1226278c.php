<div class="navbar-search-col d-inline my-2 my-lg-0 w-25" x-data="{ isOpen: true }" @click.away="isOpen = false">
    <div class="input-group">
        <input 
            wire:model.debounce.500ms="search" 
            @focus  = "isOpen = true"
            @keydown.escape.window = "isOpen = false"
            @keydown.shift.tab = "isOpen = false"
            type="text" 
            class="form-control navbar-search-input" 
            placeholder="Search" 
            aria-label="Search" 
            aria-describedby="basic-addon2">

        <span class="fa fa-search navbar-search-icon"></span>

        <div wire:loading class="spinner-border text-light navbar-search-spinner" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>

    <?php if(strlen($search) >= 1): ?>
        <div class="navbar-search-result-col" x-show="isOpen">
            
                <ul class="list-group">
                    <?php if($searchResults->count() > 0): ?>
                        <?php $__currentLoopData = $searchResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <a href="<?php echo e(route('movies.show', $search['id'])); ?>" class="text-white d-inline-flex align-items-center" <?php if($loop->last): ?> @keydown.tab="isOpen=false" <?php endif; ?>>
                                    <?php if($search['poster_path']): ?>
                                        <img src="<?php echo e('https://image.tmdb.org/t/p/w92/'.$search['poster_path']); ?>" class="navbar-search-res-img">
                                    <?php else: ?> 
                                        <img src="<?php echo e(asset('img/search-res-no-image.jpg')); ?>" alt="N/I" class="navbar-search-res-img">
                                    <?php endif; ?>
                                    <span><?php echo e($search['title']); ?></span>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <li class="list-group-item text-white">No result for "<?php echo e($search); ?>"</li>
                    <?php endif; ?>
                </ul>
        </div>
    <?php endif; ?>
</div><?php /**PATH E:\projects\laravel projects\themoviecineplex\resources\views/livewire/search-dropdown.blade.php ENDPATH**/ ?>