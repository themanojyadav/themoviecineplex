@extends('layouts.app')

@section('content')

    <div class="container text-white py-4">
        <h3>Privacy Policy</h3>
        <div>
            <p>We will update it very soon.</p>
        </div>    
    </div>    

@endsection